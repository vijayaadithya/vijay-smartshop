﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace WebApplication5
{
    public partial class Adminlogin1 : System.Web.UI.Page
    {
        string conn = ConfigurationManager.ConnectionStrings["RegConnectionString"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conn);
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from Admin where Admin_username = @Admin_username and Apassword = @Apassword", con);
            cmd.Parameters.AddWithValue("@Admin_username", TextBox1.Text);
            cmd.Parameters.AddWithValue("@Apassword", TextBox2.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {

                Response.Redirect("~/Product.aspx");

            }

            else
            {

                Label1.ForeColor = System.Drawing.Color.Red;
                Label1.Visible = true;
                Label1.Text = "Invalid Username or Password";
            }
  
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/home_page.aspx");
        }
    }
}