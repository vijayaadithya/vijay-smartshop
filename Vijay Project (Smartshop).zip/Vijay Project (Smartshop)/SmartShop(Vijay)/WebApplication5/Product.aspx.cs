﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace WebApplication5
{
    public partial class adminlogin : System.Web.UI.Page
    {
        string connn = ConfigurationManager.ConnectionStrings["RegConnectionString"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

       
        protected void Button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(connn);
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into Content values(@Product_id,@Product_type,@Product_name,@product_des,@Product_price,@Quantity,@image)", con);
                cmd.Parameters.AddWithValue("Product_id", TextBox1.Text);
                cmd.Parameters.AddWithValue("Product_type", DropDownList1.SelectedItem.Value);
                cmd.Parameters.AddWithValue("Product_name", TextBox2.Text);
                cmd.Parameters.AddWithValue("Product_des", TextBox3.Text);
                cmd.Parameters.AddWithValue("Product_price", TextBox4.Text);
                cmd.Parameters.AddWithValue("Quantity", TextBox5.Text);
                if (FileUpload1.HasFile)
                {
                    string str = FileUpload1.FileName;
                    FileUpload1.PostedFile.SaveAs(Server.MapPath("~/Upload/" + str));
                    string Image = "~/Upload/" + str.ToString();

                    cmd.Parameters.AddWithValue("image", Image);
                }
                else
                {
                    Label1.Text = "Please Upload your Image";
                    Label1.ForeColor = System.Drawing.Color.Red;
                }  
                cmd.ExecuteNonQuery();

                TextBox1.Text = "";
                TextBox2.Text = "";
                TextBox3.Text = "";
                TextBox5.Text = "";
                TextBox1.Focus();
                Label1.Visible = true;
                Label1.Text = "User registered successfully";
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            TextBox1.Text = string.Empty;
            TextBox2.Text = string.Empty; 
            TextBox3.Text = string.Empty;
            TextBox4.Text = string.Empty;
            TextBox5.Text = string.Empty;
        }

        //protected void Button1_Click(object sender, EventArgs e)
        //{

        //    System.IO.Stream fs = FileUpload1.PostedFile.InputStream;
        //    System.IO.BinaryReader br = new System.IO.BinaryReader(fs);
        //    Byte[] bytes = br.ReadBytes((Int32)fs.Length);
        //    string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
        //    Image1.ImageUrl = "data:image/png;base64," + base64String;
        //    Image1.Visible = true;
        //}

      
        
    }
}