﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace WebApplication5
{
    public partial class login_page : System.Web.UI.Page
    {
        string conn = ConfigurationManager.ConnectionStrings["RegConnectionString"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

       

        //protected void Button3_Click1(object sender, EventArgs e)
        //{
            
        //}
            //int count = Convert.ToInt32(cmd.ExecuteScalar());
            //if (count == 1)
            //{
            //    Response.Redirect("~/customer_login/index.html");
            //}
            //else
            //{
            //    Label1.Visible = true;
            //}
        

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/home_page.aspx");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conn);
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from CustomerDetails where User_name = @User_name and Upassword = @Upassword", con);
            cmd.Parameters.AddWithValue("@User_name", TextBox1.Text);
            cmd.Parameters.AddWithValue("@Upassword", TextBox2.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {

                Response.Redirect("~/producthome.aspx");

            }

            else
            {
                Label1.ForeColor = System.Drawing.Color.Red;
                Label1.Visible = true;
                Label1.Text = "Invalid Username or Password";
            }
        }

       
    }
}