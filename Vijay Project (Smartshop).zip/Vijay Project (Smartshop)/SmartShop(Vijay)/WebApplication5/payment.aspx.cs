﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
namespace WebApplication5
{
    public partial class payment : System.Web.UI.Page
    {
        string conn = ConfigurationManager.ConnectionStrings["RegConnectionString"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conn);
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into Address values(@name,@mobile,@landmark,@place,@add_type,@payment)", con);
                cmd.Parameters.AddWithValue("name", TextBox1.Text);
                cmd.Parameters.AddWithValue("mobile", TextBox2.Text);
                cmd.Parameters.AddWithValue("landmark", TextBox3.Text);
                cmd.Parameters.AddWithValue("place", TextBox4.Text);
                cmd.Parameters.AddWithValue("add_type", DropDownList1.SelectedItem.Value);
                cmd.Parameters.AddWithValue("payment", RadioButtonList1.SelectedItem.Text);

                cmd.ExecuteNonQuery();
                //Response.Redirect("~/home_page.aspx");
                //Response.Redirect("~/customer_login/index.html");

                TextBox1.Text = "";
                TextBox2.Text = "";
                TextBox3.Text = "";
                TextBox4.Text = "";
                DropDownList1.SelectedItem.Value="";
               
                TextBox1.Focus();
                Label1.Visible = true;
                Label1.Text = "Payment Sucessful";
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox1.Text = string.Empty;
            TextBox2.Text = string.Empty;
            TextBox3.Text = string.Empty;
            TextBox4.Text = string.Empty;
            DropDownList1.SelectedIndex = 0;
            RadioButtonList1.SelectedIndex = 0;
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/AddCart.aspx");
        }
    }
}