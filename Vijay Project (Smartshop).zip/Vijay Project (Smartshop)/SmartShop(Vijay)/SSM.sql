create database SSM

CREATE TABLE CustomerDetails 
(
    Username NVARCHAR (50) NOT NULL,
    Email     NVARCHAR (50) NOT NULL,
    Upassword  NVARCHAR (50) NOT NULL,
    Rpassword NVARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED (Username ASC)
)


alter procedure addcustomerdetails @Username NVARCHAR (50) , @Email NVARCHAR (50) ,@Upassword  NVARCHAR (50), @Rpassword NVARCHAR (50) 
As
Begin
	Insert into CustomerDetails values(@Username, @Email ,@Upassword ,@Rpassword)
End
/*
alter procedure validatecustomer  @Username NVARCHAR (50) ,@Upassword  NVARCHAR (50) ,@status varchar(10) out
as
begin
	 
	declare @Username1 nvarchar(50)
	set @Username='nothing'
	declare @Upassword1 nvarchar(50)
	set @Upassword='nothing'
	select   @Username1 = Username, @Upassword1 = Upassword  from  Customer where Username = @Username and Upassword = @Upassword
	if  @Username = 'nothing' AND  @Upassword = 'nothing' 
	 set @status = 'invalid'
	 else 
	set @status='valid' 
     
end
*/
select*from customerDetails
insert into customerDetails(Username, Email ,Upassword ,Rpassword)
values('user','user@gmail.com','pass','pass');

CREATE TABLE Admin (
    Admin_username NVARCHAR (50) NOT NULL,
    Apassword       NVARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED (Admin_username ASC)
)




/*
alter procedure validateadmin   NVARCHAR (50) ,@Apassword  NVARCHAR (50) ,@astatus varchar(10) out
as
begin
	 
	declare @Admin_username1 nvarchar(50)
	set @Admin_username1 ='nothing'
	declare @Apassword1 nvarchar(50)
	set @Apassword1='nothing'
	select   @Admin_username1 = Admin_username, @Apassword1 = Apassword  from   Admin  where Admin_username = @Admin_username and Apassword = @Apassword
	if  @Admin_username1 = 'nothing' AND  @Apassword1 = 'nothing' 
	 set @astatus = 'invalid'
	 else 
	set @astatus='valid' 
     
end
*/
Select *from Admin
insert into Admin(Admin_username,Apassword)
values('adlogin','admin');



CREATE TABLE Content
 (
    Product_id    INT            NOT NULL,
    Product_type  NVARCHAR (50)  NOT NULL,
    Product_name  NVARCHAR (50)  NOT NULL,
    Product_des   NVARCHAR (150) NOT NULL,
    Product_price NVARCHAR (50)  NOT NULL,
    Quantity     INT            NOT NULL,
    imag        VARCHAR (150)  NOT NULL,
    PRIMARY KEY CLUSTERED (Product_id ASC)
)



alter procedure AddProductDetails @Product_id int,@Product_type  nvarchar (50), @product_name varchar(50), @Product_des nvarchar (150) ,@Product_price nvarchar (50), @imag varchar(150),@Quantity  int 
 as
 begin
    insert into Content values(@Product_id,@Product_type,@product_Name ,@Product_des,@Product_price, @imag ,@Quantity)
	end

select*from Content
insert into Content(Product_id,Product_type,product_Name ,Product_des,Product_price ,Quantity,imag)
values('5001','Camera','Cannon EOS 700D','	ef'	,'99999','5','~/Upload/c1(Cannon EOS 700D Dslr).jfif');





CREATE TABLE UserAddress 
(
    name     NVARCHAR (50) NULL,
    mobile   NCHAR (10)    NULL,
    landmark NVARCHAR (50) NULL,
    place    NVARCHAR (50) NULL,
    add_type NVARCHAR (50) NULL,
    payment  NVARCHAR (50) NULL
)


alter procedure addcustomeraddress  @name NVARCHAR (50) ,@mobile NCHAR (10),@landmark NVARCHAR (50) ,@place NVARCHAR (50),@add_type NVARCHAR (50),@payment  NVARCHAR (50)
As
Begin
	Insert into UserAddress values(@name, @mobile ,@landmark ,@place,@add_type,@payment)
End
